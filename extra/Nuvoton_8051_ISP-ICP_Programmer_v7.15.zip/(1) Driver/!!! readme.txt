Note:
  The ISP/ICP/NuGang Programmers have the USB-to-Serial bridge chip (PL-2303) built
  inside. When connected to PC, it will appear as a USB-to-Serial COM port in the
  'System\Hardware\Device Manager'. Before starting to use these programmers, the user
  needs to install the driver in PC if the PL-2303 driver has never been installed. 

  If need, the driver may be updated by downloading the newer revision from the
  web-site of Prolific Tech. Inc.:

     http://www.prolific.com.tw/US/ShowProduct.aspx?p_id=225&pcid=41