Note:
    Doubly click the setup file to install this application program in PC.

    The application program can be used for the following tools:

    (1) ISP Programmer
    (2) ISP by COM Port    
    (3) ICP Programmer
    (4) NuGang Programmer (Gang-4 programming for customers' mass production)
