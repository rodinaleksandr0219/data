Note:
    (1) Before using 'ISP Programmer' and 'ISP by COM Port', the "Nuvoton standard ISP code"
        should be pre-programmed in MCU's LDROM by using a universal programmer.
        
        For the following parts, the programming of ISP code is done in Nuvoton's factory:

	W78E052D, W78E054D, W78E058D, W78E516D, N78E366A, N78E055A, N78E059A and N78E517A.
        

    (2) For 'ICP Programmer', there doesn't need any ISP code pre-programmed in MCU's LDROM.
